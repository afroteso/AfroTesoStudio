# AfroTesoStudio 🎶

AfroTesoStudio is a free and open-source Android music creation app inspired by African rhythm, Afro-Teso culture, and community-driven creativity.

## Features
- Drum engine (Afro-Teso rhythms)
- Audio engine (SoundFont / PCM)
- GPL v3 licensed (community freedom)
A library for African cultural art audio visualisation in music and AI video generation
 narrated by Africans themselves to the entire 🌎 world.
  mission:TO work alongside UNESCO
 in preservation of African historical culture for future generations heritage
## License
This project is licensed under the GNU General Public License v3.0  
See the LICENSE file for details.

## Author
Elly Ijakaa  
Kenya 🇰🇪